public interface Actionable {
    void performAction();
}

